#include <stdint.h>

#define N_SAMPLES 10
#define SAMPLES_X_SIZE 1
#define SAMPLES_Y_SIZE 1

extern float samples_x[10][1];
extern float samples_y[10][1];
