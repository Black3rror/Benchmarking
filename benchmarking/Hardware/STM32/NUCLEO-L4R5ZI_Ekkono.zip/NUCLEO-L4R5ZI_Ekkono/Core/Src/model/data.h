#define N_SAMPLES 10

extern float samples_x[N_SAMPLES][1];
extern float samples_y[N_SAMPLES][1];
