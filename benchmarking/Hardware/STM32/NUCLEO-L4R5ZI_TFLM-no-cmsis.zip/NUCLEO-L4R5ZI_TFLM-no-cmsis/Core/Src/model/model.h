#include <cstdint>
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"

using namespace std;

#define ARENA_SIZE 1024    // estimated: 10248, founded: 1024

#define INPUT_DTYPE float
#define INPUT_N_DIMS 1
#define INPUT_DIM_0_SIZE 1
#define OUTPUT_DTYPE float
#define OUTPUT_N_DIMS 1
#define OUTPUT_DIM_0_SIZE 1
#define N_OPERATORS 2

extern const unsigned int model_data_size;
extern const unsigned char model_data[];

TfLiteStatus op_resolver(tflite::MicroMutableOpResolver<N_OPERATORS>* resolver_ptr);
