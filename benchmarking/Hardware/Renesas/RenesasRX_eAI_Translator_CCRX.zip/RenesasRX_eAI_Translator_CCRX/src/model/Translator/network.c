/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED 'AS IS' AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Changed from original python code to C source code.
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : network.c
* Version      : 1.00
* Description  : Definitions of all functions
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 16.06.2017 1.00     First Release
***********************************************************************************************************************/

#include "stdlib.h"
#include "Typedef.h"
#include "math.h"
#include "layer_graph.h"
#define C_FP32 1
/***********************************************************************************************************************
* Function Name: innerproduct
* Description  : - Fully connected layer
*                - Performs dot product of data and weights and add them up with biases
*                   (Matrix Multiplication of data and weights and addition of biases)
* Arguments    : data           - Array of input data
*                weights        - Array of weights (transposed)
*                biases 		- Array of biases
*                out            - Placeholder for the output
*                shapes         - Dimensions of data and weights (N, D, F, D)
*                errorcode - errorcode if any issue in memory allocation
* Return Value : no return value
***********************************************************************************************************************/
void innerproduct(TPrecision *data, const TPrecision *weights, const TPrecision *biases,TPrecision *out,TsInt *shapes,TsInt *errorcode)
{
	if (*errorcode!=1)
	{
		TsInt iColumn;
		TsInt iInneritr;
		TsInt D = shapes[1];
		TsInt F = shapes[3];
				
		// Execute C Innerproduct or CCRX complier or CCRL complier    
		#if defined C_FP32 || defined __CCRX__ || defined __CCRL__
		TPrecision dSum = 0;

		for(iColumn=0; iColumn<F; iColumn++)
		{
			dSum = 0;
			for(iInneritr=0; iInneritr<D;iInneritr++)
			{
				dSum += data[iInneritr] * weights[(iInneritr*F)+iColumn];
			}
			if (biases)
			{
				out[iColumn] = dSum + biases[iColumn];				// output
			}
			else{
				out[iColumn] = dSum;
			}
		}
	}
	
	#endif
}

/***********************************************************************************************************************
* Function Name: Sigmoid
* Description  : element wise operation and squashes all values between 0 and 1
* Arguments	   : data	- Array of input data
*                dOut   - Pointer to the output data
*				 shapes	- Size of the input array
*                errorcode - errorcode if any issue in memory allocation
* Return Value : no return value
***********************************************************************************************************************/
void sigmoid(TPrecision *dData, TPrecision *dOut, TsInt iShapes,TsInt *errorcode)
{
    if (*errorcode!=1)
    {
        TsInt iRow;

        // Executes  CCRX complier or CCRL complier
        #if  defined __CCRX__ || defined __CCRL__
        float *dArray;

        //Creation of dynamic array
        dArray = (float *)malloc(iShapes* sizeof(float));

        //Check dAve matix memory is allocated
        if(dArray == NULL){
            // Errorcode is set to 1 when there is Memory Allocation Failure for dArray array
            *errorcode = 1;
            return;
        }

        for (iRow=0; iRow<iShapes; iRow++)
        {
            dArray[iRow] =  (1+exp(-dData[iRow]));
        }
        for (iRow=0; iRow<iShapes; iRow++)
        {
            dOut[iRow] = 1/dArray[iRow];      //output
        }
        free(dArray);
        dArray = NULL;

        // Executes  C Sigmoid
        #elif  defined C_FP32
        TPrecision dArray[iShapes];

        for (iRow=0; iRow<iShapes; iRow++)
        {
            dArray[iRow] = (TPrecision)(1+exp(-dData[iRow]));
        }
        for (iRow=0; iRow<iShapes; iRow++)
        {
            dOut[iRow] = 1/dArray[iRow];      //output
        }
        #endif
    }
    

}



