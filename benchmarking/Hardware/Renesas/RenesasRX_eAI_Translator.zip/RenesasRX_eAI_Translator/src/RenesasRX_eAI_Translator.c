/***********************************************************************
*
*  FILE        : RenesasRX_eAI_Translator.c
*  DATE        : 2024-08-09
*  DESCRIPTION : Main Program
*
*  NOTE:THIS IS A TYPICAL EXAMPLE.
*
***********************************************************************/
#include "r_smc_entry.h"
#include "benchmark.h"

void main(void);

void main(void)
{
    benchmark(10, 0);
}
