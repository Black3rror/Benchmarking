#include "Typedef.h"

typedef struct 
{   const TPrecision *input_weight;
	const TPrecision *forgot_weight;
	const TPrecision *cellstate_weight;
	const TPrecision *output_weight;
}LSTM_weights;

typedef struct 
{   const TPrecision *input_bias;
	const TPrecision *forgot_bias;
	const TPrecision *cellstate_bias;
	const TPrecision *output_bias;
}LSTM_bias;

typedef struct 
{   const TPrecision *input_weight;
	const TPrecision *forgot_weight;
	const TPrecision *cellstate_weight;
}GRU_weights;

typedef struct 
{   const TPrecision *input_bias;
	const TPrecision *forgot_bias;
	const TPrecision *cellstate_bias;
}GRU_bias;