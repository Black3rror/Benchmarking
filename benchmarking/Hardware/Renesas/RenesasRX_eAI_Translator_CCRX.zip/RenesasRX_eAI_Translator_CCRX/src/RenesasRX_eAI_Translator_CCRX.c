/***********************************************************************
*
*  FILE        : RenesasRX_eAI_Translator_CCRX.c
*  DATE        : 2024-08-16
*  DESCRIPTION : Main Program
*
*  NOTE:THIS IS A TYPICAL EXAMPLE.
*
***********************************************************************/
#include "r_smc_entry.h"
#include "benchmark.h"

void main(void);

void main(void)
{
    benchmark(10, 0);
}
