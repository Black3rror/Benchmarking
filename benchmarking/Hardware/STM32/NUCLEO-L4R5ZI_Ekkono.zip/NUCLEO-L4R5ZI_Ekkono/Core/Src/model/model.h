#define MODEL_TYPE PRETRAINED
#define ARENA_SIZE 376
#define INPUT_SIZE 1

extern const unsigned int model_data_size;
extern const unsigned char model_data[];
