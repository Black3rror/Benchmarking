#include <cstdint>

using namespace std;

#define N_SAMPLES 10

extern float samples_x[10][1];
extern float samples_y[10][1];
